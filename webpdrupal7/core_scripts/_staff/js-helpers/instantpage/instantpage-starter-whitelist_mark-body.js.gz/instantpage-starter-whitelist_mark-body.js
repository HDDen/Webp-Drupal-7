(function(){
	document.getElementsByTagName("body")[0].setAttribute('data-instant-whitelist', '');
})();
